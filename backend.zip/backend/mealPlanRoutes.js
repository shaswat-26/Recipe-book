const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const SECRET_KEY = process.env.JWT_SECRET;
const mealPlanController = require("./mealPlanController");

// Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Token missing" });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ error: "Invalid token" });
        req.user = user;
        next();
    });
}

// ======================== ROUTES =================================
// GET today's meal plan
router.get("/today", authenticateToken, (req, res) => {
    const today = new Date().toISOString().split("T")[0];
    req.params.date = today;
    mealPlanController.getMealPlan(req, res);
});

// Add to meal plan
router.post("/add", authenticateToken, mealPlanController.addToMealPlan);

// Get meal plan for a date
router.get("/:date", authenticateToken, mealPlanController.getMealPlan);

// Shopping list
router.get(
    "/shopping/:start_date/:end_date",
    authenticateToken,
    mealPlanController.getShoppingList
);

module.exports = router;
