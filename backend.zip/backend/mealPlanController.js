const db = require("./db");

// ======================= ADD RECIPE TO MEAL PLAN =======================
exports.addToMealPlan = (req, res) => {
    const { date, meal_type, recipe_id } = req.body;
    const user_id = req.user.id;

    if (!date || !meal_type || !recipe_id)
        return res.status(400).json({ error: "All fields required" });

    const sql = "INSERT INTO meal_plans (user_id, date, meal_type, recipe_id) VALUES (?, ?, ?, ?)";
    db.query(sql, [user_id, date, meal_type, recipe_id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Recipe added to meal plan!" });
    });
};

// ======================= GET MEAL PLAN =======================
exports.getMealPlan = (req, res) => {
    const user_id = req.user.id;
    const { date } = req.params;

    const sql = `
        SELECT 
            mp.id,
            mp.meal_type,
            r.id AS recipe_id,
            r.title AS recipe_title,
            r.ingredients,
            r.image AS recipe_image   -- ✅ FIX: Return image also
        FROM meal_plans mp
        JOIN recipes r ON mp.recipe_id = r.id
        WHERE mp.user_id = ? AND mp.date = ?
        ORDER BY mp.meal_type
    `;

    db.query(sql, [user_id, date], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        const mealPlan = results.map(item => ({
            id: item.id,
            meal_type: item.meal_type,
            recipe_id: item.recipe_id,
            recipe_title: item.recipe_title,
            ingredients: item.ingredients,
            recipe_image: item.recipe_image   // ✅ Added image
        }));

        res.json(mealPlan);
    });
};

// ======================= GET SHOPPING LIST =======================
exports.getShoppingList = (req, res) => {
    const user_id = req.user.id;
    const { start_date, end_date } = req.params;

    const sql = `
        SELECT r.ingredients
        FROM meal_plans mp
        JOIN recipes r ON mp.recipe_id = r.id
        WHERE mp.user_id = ? AND mp.date BETWEEN ? AND ?
    `;

    db.query(sql, [user_id, start_date, end_date], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        const shoppingList = {};

        results.forEach(recipe => {
            try {
                const ingredients = JSON.parse(recipe.ingredients);
                ingredients.forEach(item => {
                    if (shoppingList[item.name]) {
                        shoppingList[item.name] += parseFloat(item.quantity);
                    } else {
                        shoppingList[item.name] = parseFloat(item.quantity);
                    }
                });
            } catch (e) {
                console.error("Invalid ingredient format:", recipe.ingredients);
            }
        });

        res.json(shoppingList);
    });
};
