// server.js
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");
const path = require("path");
const multer = require("multer");
require("dotenv").config();
const auth = require("./authMiddleware");

const app = express();



app.use(cors());
app.use(express.json());

const mealPlanRoutes = require("./mealPlanRoutes");
app.use("/api/meal-planner", mealPlanRoutes);


// ======================= MULTER SETUP ============================
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "uploads"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage });

// Serve uploaded images
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Serve frontend
app.use(express.static(path.join(__dirname, "../frontend")));


// ======================= REGISTER ================================
app.post("/api/register", async (req, res) => {
  const { username, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    [username, hashedPassword],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "User registered successfully" });
    }
  );
});

// ======================= LOGIN ==================================
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    async (err, results) => {
      if (err) return res.status(500).json({ error: err });
      if (results.length === 0)
        return res.status(400).json({ message: "User not found" });

      const user = results[0];
      const isMatch = await bcrypt.compare(password, user.password);

      if (!isMatch)
        return res.status(400).json({ message: "Incorrect password" });

      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
        expiresIn: "7d",
      });

      res.json({ token });
    }
  );
});

// ======================= GET ALL RECIPES ==========================
app.get("/api/recipes", (req, res) => {
  db.query(
    "SELECT id, title, ingredients, image FROM recipes ORDER BY id DESC",
    (err, results) => {
      if (err) return res.status(500).json({ error: err });
      res.json(results);
    }
  );
});

// ======================= GET SINGLE RECIPE =======================
app.get("/api/recipes/:id", (req, res) => {
  db.query(
    "SELECT * FROM recipes WHERE id = ?",
    [req.params.id],
    (err, results) => {
      if (err) return res.status(500).json({ error: err });
      if (results.length === 0)
        return res.status(404).json({ message: "Recipe not found" });

      res.json(results[0]);
    }
  );
});

// ======================= ADD RECIPE (WITH IMAGE) =================
app.post("/api/recipes", auth, upload.single("image"), (req, res) => {
  const { title, ingredients, instructions } = req.body;

  const image = req.file ? req.file.filename : null;

  if (!title || !ingredients || !instructions)
    return res.status(400).json({ message: "All fields are required" });

  db.query(
    "INSERT INTO recipes (title, ingredients, instructions, image) VALUES (?, ?, ?, ?)",
    [title, ingredients, instructions, image],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Recipe added successfully" });
    }
  );
});

// ======================= DEFAULT ROUTE ============================
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

// ======================= START SERVER =============================
const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
