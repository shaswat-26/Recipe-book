// routes/mealPlanner.js
const express = require('express');
const router = express.Router();
const db = require('../db'); // your mysql2 promise pool; adapt if named differently
const authenticate = require('../middleware/authenticate');

// Helper to validate meal_type
const validMeals = ['Breakfast','Lunch','Dinner'];

// POST /api/meal-planner
router.post('/', authenticate, async (req, res) => {
  try {
    const user_id = req.user.id;
    const { date, meal_type, recipe_id } = req.body;
    if (!date || !meal_type || !recipe_id) return res.status(400).json({ error: 'Missing fields' });
    if (!validMeals.includes(meal_type)) return res.status(400).json({ error: 'Invalid meal_type' });

    // Option A: try insert and rely on UNIQUE constraint -> replace existing entry for that slot
    await db.query(
      `INSERT INTO meal_plans (user_id,date,meal_type,recipe_id)
       VALUES (?,?,?,?)
       ON DUPLICATE KEY UPDATE recipe_id=VALUES(recipe_id), created_at=CURRENT_TIMESTAMP`,
      [user_id, date, meal_type, recipe_id]
    );

    res.json({ message: 'Meal saved' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/meal-planner?start=YYYY-MM-DD&end=YYYY-MM-DD
// returns list of plans for the user with recipe info
router.get('/', authenticate, async (req, res) => {
  try {
    const user_id = req.user.id;
    let { start, end } = req.query;

    // If missing, default to current week's Monday-Sunday
    if (!start || !end) {
      const now = new Date();
      const day = now.getDay(); // 0=Sun..6=Sat
      const diffToMonday = ((day + 6) % 7); // days since Monday
      const monday = new Date(now);
      monday.setDate(now.getDate() - diffToMonday);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      const fmt = d => d.toISOString().slice(0,10);
      start = fmt(monday);
      end = fmt(sunday);
    }

    const [rows] = await db.query(
      `SELECT mp.id, mp.date, mp.meal_type, mp.recipe_id,
              r.title AS recipe_title, r.image AS recipe_image
       FROM meal_plans mp
       JOIN recipes r ON r.id = mp.recipe_id
       WHERE mp.user_id = ? AND mp.date BETWEEN ? AND ?
       ORDER BY mp.date, FIELD(mp.meal_type, 'Breakfast','Lunch','Dinner')`,
      [user_id, start, end]
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/meal-planner/:id
router.delete('/:id', authenticate, async (req, res) => {
  try {
    const user_id = req.user.id;
    const id = req.params.id;

    // ensure the entry belongs to user
    const [rows] = await db.query('SELECT id FROM meal_plans WHERE id=? AND user_id=?', [id, user_id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });

    await db.query('DELETE FROM meal_plans WHERE id=?', [id]);
    res.json({ message: 'Meal removed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
