// script.js (updated)
// Keep this file under frontend and include in all pages (view.html, add.html, meal-planner.html)

document.addEventListener("DOMContentLoaded", () => {
  setupAuthUI();
  bindForms();
  // Load recipes if container exists
  if (document.getElementById("recipes")) loadRecipes();
  // Load planner if on planner page
  if (document.getElementById("mealGrid")) initMealPlanner();
});

// -------------------- AUTH UI & common --------------------
function setupAuthUI() {
  const token = localStorage.getItem("token");
  const logoutBtn = document.getElementById("logoutBtn");
  const loginLink = document.getElementById("loginLink");
  const registerLink = document.getElementById("registerLink");
  const addRecipeLink = document.getElementById("addRecipeLink");

  if (logoutBtn) logoutBtn.style.display = token ? "inline-block" : "none";
  if (loginLink) loginLink.style.display = token ? "none" : "inline-block";
  if (registerLink) registerLink.style.display = token ? "none" : "inline-block";
  if (addRecipeLink) addRecipeLink.style.display = token ? "inline-block" : "none";

  logoutBtn?.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "index1.html";
  });
}

// -------------------- FORM BINDINGS (login/register/add recipe) --------------------
function bindForms() {
  document.getElementById("loginForm")?.addEventListener("submit", async e => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) return alert(data.error || "Login failed");
    localStorage.setItem("token", data.token);
    window.location.href = "index1.html";
  });

  document.getElementById("registerForm")?.addEventListener("submit", async e => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) return alert(data.error || "Registration failed");
    alert("Registered! Please login.");
    window.location.href = "login.html";
  });

  // Add recipe submit (single-image)
  document.getElementById("recipeForm")?.addEventListener("submit", async e => {
    e.preventDefault();
    const tokenNow = localStorage.getItem("token");
    if (!tokenNow) {
      alert("Please login");
      window.location.href = "login.html";
      return;
    }
    const formData = new FormData();
    formData.append("title", document.getElementById("title").value);
    formData.append("ingredients", document.getElementById("ingredients").value);
    formData.append("instructions", document.getElementById("instructions").value);
    const file = document.getElementById("image")?.files[0];
    if (file) formData.append("image", file);

    const res = await fetch("/api/recipes", {
      method: "POST",
      headers: { Authorization: "Bearer " + tokenNow },
      body: formData
    });
    const data = await res.json();
    if (!res.ok) return alert(data.error || "Failed to add recipe");
    alert("Recipe added!");
    document.getElementById("recipeForm").reset();
    document.getElementById("previewContainer")?.replaceChildren();
  });

  // image preview
  document.getElementById("image")?.addEventListener("change", () => {
    const container = document.getElementById("previewContainer");
    if (!container) return;
    container.innerHTML = "";
    const file = document.getElementById("image").files[0];
    if (!file) return;
    const img = document.createElement("img");
    img.src = URL.createObjectURL(file);
    img.style.width = "120px";
    img.style.height = "120px";
    img.style.objectFit = "cover";
    img.style.borderRadius = "10px";
    img.style.border = "2px solid #ddd";
    container.appendChild(img);
  });
}

// Search Filter
document.addEventListener("input", function (e) {
  if (e.target.id === "searchInput") {
    const query = e.target.value.toLowerCase();
    const cards = document.querySelectorAll(".recipe-card");

    cards.forEach(card => {
      const title = card.querySelector("h3").textContent.toLowerCase();

      if (title.includes(query)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  }
});

// -------------------- LOAD RECIPES (for view.html) --------------------
async function loadRecipes() {
  try {
    const res = await fetch("/api/recipes");
    const data = await res.json();
    const container = document.getElementById("recipes");
    container.innerHTML = "";
    if (!data || data.length === 0) {
      container.innerHTML = "<p>No recipes found</p>";
      return;
    }

    data.forEach(recipe => {
      const imgPath = recipe.image ? `/uploads/${recipe.image}` : '/uploads/placeholder.png';
      const card = document.createElement("div");
      card.className = "recipe-card";
      card.innerHTML = `
        <img src="${imgPath}" alt="${escapeHtml(recipe.title)}">
        <h3>${escapeHtml(recipe.title)}</h3>
        <p>${escapeHtml(truncate(recipe.ingredients || "", 120))}${(recipe.ingredients||"").length>120?"...":""}</p>
        <div style="display:flex; gap:8px; margin-top:8px;">
          <button class="view-btn">View</button>
          <button class="add-plan-btn">➕ Add to Meal Plan</button>
        </div>
      `;
      // click view opens modal
      card.querySelector('.view-btn').addEventListener('click', () => {
        openRecipeModal(recipe, imgPath);
      });
      // add to plan opens schedule modal
      card.querySelector('.add-plan-btn').addEventListener('click', () => {
        openScheduleModalForRecipe(recipe.id);
      });
      container.appendChild(card);
    });
  } catch (err) {
    console.error(err);
    const container = document.getElementById("recipes");
    if (container) container.innerHTML = "<p>Error loading recipes.</p>";
  }
}

function escapeHtml(s) {
  if (!s) return '';
  return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[c]));
}
function truncate(s, n) { return s && s.length > n ? s.slice(0,n) : s || "" }

// -------------------- MODAL: View Recipe --------------------
function openRecipeModal(recipe, imgPath) {
  document.getElementById("modalTitle").textContent = recipe.title;
  document.getElementById("modalIngredients").textContent = recipe.ingredients || "";
  document.getElementById("modalInstructions").textContent = recipe.instructions || "";
  document.getElementById("modalImage").src = imgPath;
  const openScheduleFromView = document.getElementById("openScheduleFromView");
  if (openScheduleFromView) {
    openScheduleFromView.dataset.recipeId = recipe.id;
    openScheduleFromView.onclick = () => openScheduleModalForRecipe(recipe.id);
  }
  document.getElementById("modal").classList.remove("hidden");
}
document.getElementById("closeModal")?.addEventListener("click", () => {
  document.getElementById("modal").classList.add("hidden");
});

// -------------------- SCHEDULING MODAL --------------------
let scheduleSelectedRecipeId = null;

function openScheduleModalForRecipe(recipeId) {
  scheduleSelectedRecipeId = recipeId;
  // If there's a scheduleModal on page (view.html) use it; else create inline simple prompt.
  const modal = document.getElementById("scheduleModal");
  if (modal) {
    // default date = today
    document.getElementById("mealDate").value = new Date().toISOString().slice(0,10);
    document.getElementById("mealType").value = "Dinner";
    modal.classList.remove("hidden");
  } else {
    // fallback: simple prompt
    const date = prompt("Date (YYYY-MM-DD)", new Date().toISOString().slice(0,10));
    const meal = prompt("Meal (Breakfast, Lunch, Dinner)", "Dinner");
    if (!date || !meal) return;
    saveMealPlan({ date, meal_type: meal, recipe_id: recipeId });
  }
}

document.getElementById("closeSchedule")?.addEventListener("click", () => {
  document.getElementById("scheduleModal").classList.add("hidden");
});

document.getElementById("saveMealPlanBtn")?.addEventListener("click", async () => {
  const date = document.getElementById("mealDate").value;
  const meal_type = document.getElementById("mealType").value;
  if (!date || !meal_type || !scheduleSelectedRecipeId) return alert("Missing data");
  await saveMealPlan({ date, meal_type, recipe_id: scheduleSelectedRecipeId });
  document.getElementById("scheduleModal").classList.add("hidden");
  // If planner is open, reload it
  if (document.getElementById("mealGrid")) loadWeek(currentWeekStart);
});

// -------------------- SAVE MEAL PLAN (POST) --------------------
async function saveMealPlan({ date, meal_type, recipe_id }) {
  try {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Please login to add to meal plan");
      window.location.href = "login.html";
      return;
    }
    const res = await fetch('/api/meal-planner/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ date, meal_type, recipe_id })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed');
    alert(data.message || 'Saved');
  } catch (err) {
    console.error(err);
    alert(err.message || 'Error saving meal');
  }
}

// -------------------- MEAL PLANNER (weekly grid) --------------------
let currentWeekStart = null; // 'YYYY-MM-DD' Monday

function initMealPlanner() {
  // compute current week start (Monday)
  currentWeekStart = getMondayISO(new Date());
  document.getElementById('weekLabel').textContent = weekLabelForStart(currentWeekStart);
  document.getElementById('prevWeek').addEventListener('click', () => {
    currentWeekStart = shiftISOWeek(currentWeekStart, -1);
    document.getElementById('weekLabel').textContent = weekLabelForStart(currentWeekStart);
    loadWeek(currentWeekStart);
  });
  document.getElementById('nextWeek').addEventListener('click', () => {
    currentWeekStart = shiftISOWeek(currentWeekStart, 1);
    document.getElementById('weekLabel').textContent = weekLabelForStart(currentWeekStart);
    loadWeek(currentWeekStart);
  });
  loadWeek(currentWeekStart);
}

function getMondayISO(d) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = (day + 6) % 7; // days since Monday
  date.setDate(date.getDate() - diff);
  return date.toISOString().slice(0,10);
}
function shiftISOWeek(startISO, deltaWeeks) {
  const date = new Date(startISO);
  date.setDate(date.getDate() + deltaWeeks * 7);
  return date.toISOString().slice(0,10);
}
function weekLabelForStart(startISO) {
  const s = new Date(startISO);
  const e = new Date(s);
  e.setDate(s.getDate() + 6);
  return `${s.toDateString()} → ${e.toDateString()}`;
}
function weekDatesFromStart(startISO) {
  const arr = [];
  const s = new Date(startISO);
  for (let i=0;i<7;i++){
    const d = new Date(s);
    d.setDate(s.getDate() + i);
    arr.push(d.toISOString().slice(0,10));
  }
  return arr;
}

async function loadWeek(startISO) {
  try {
    const token = localStorage.getItem("token");
    if (!token) {
      document.getElementById('mealGrid').innerHTML = '<p>Please login to view your meal plan.</p>';
      return;
    }
    const start = startISO;
    const d = new Date(startISO);
    const end = new Date(d);
    end.setDate(d.getDate() + 6);
    const endISO = end.toISOString().slice(0,10);

    const res = await fetch(`/api/meal-planner?start=${start}&end=${endISO}`, {
      headers: { Authorization: 'Bearer ' + token }
    });
    const plans = await res.json();
    renderMealGrid(plans, startISO);
  } catch (err) {
    console.error(err);
    document.getElementById('mealGrid').innerHTML = '<p>Error loading meal planner.</p>';
  }
}

function renderMealGrid(plans, startISO) {
  const container = document.getElementById('mealGrid');
  container.innerHTML = '';
  const dates = weekDatesFromStart(startISO);
  // index plans into map date->meal->entry
  const map = {};
  plans.forEach(p => {
    if (!map[p.date]) map[p.date] = {};
    map[p.date][p.meal_type] = p;
  });

  dates.forEach(dateISO => {
    const dayCol = document.createElement('div');
    dayCol.className = 'day-column';
    const dayName = new Date(dateISO).toDateString().slice(0,10);
    dayCol.innerHTML = `<h3>${dayName}</h3>`;
    ['Breakfast','Lunch','Dinner'].forEach(meal => {
      const entry = map[dateISO] && map[dateISO][meal] ? map[dateISO][meal] : null;
      const slot = document.createElement('div');
      slot.className = 'slot ' + (entry ? 'filled' : 'empty');
      if (!entry) {
        slot.innerHTML = `<div style="width:100%; text-align:center;">➕ Add ${meal}</div>`;
        slot.addEventListener('click', () => {
          // set selected and show modal
          scheduleSelectedRecipeId = null; // not selecting recipe here; user will pick recipe separately
          // we will offer a simple picker: show prompt to enter recipe id, or redirect to view page to pick
          const pick = confirm("Would you like to pick a recipe from All Recipes? OK = pick there, Cancel = quick-add by recipe ID");
          if (pick) {
            // redirect to view page and store intent in localStorage to open date/meal
            localStorage.setItem('mealPlannerIntent', JSON.stringify({ date: dateISO, meal }));
            window.location.href = 'view.html';
          } else {
            const rid = prompt("Enter recipe id to schedule:");
            if (rid) saveMealPlan({ date: dateISO, meal_type: meal, recipe_id: Number(rid) })
              .then(()=> loadWeek(currentWeekStart));
          }
        });
      } else {
        const imgPath = entry.recipe_image ? `/uploads/${entry.recipe_image}` : '/uploads/placeholder.png';
        slot.innerHTML = `
          <img src="${imgPath}" />
          <p>${escapeHtml(entry.recipe_title || 'Recipe')}</p>
          <button class="del">🗑</button>
        `;
        slot.querySelector('.del').addEventListener('click', async (ev) => {
          ev.stopPropagation();
          if (!confirm('Remove this meal?')) return;
          await deleteMeal(entry.id);
          loadWeek(currentWeekStart);
        });
      }
      dayCol.appendChild(slot);
    });
    container.appendChild(dayCol);
  });
}

async function loadTodayMealPlan() {
  const token = localStorage.getItem("token");
  const res = await fetch("/api/meal-planner/today", {
    headers: { "Authorization": "Bearer " + token }
  });

  const data = await res.json();

  let box = document.getElementById("todayMealPlan");
  box.innerHTML = "";

  if (data.length === 0) {
    box.innerHTML = "<p>No meal plan for today</p>";
    return;
  }

  data.forEach(meal => {
    box.innerHTML += `
      <div class="meal-card">
        <h3>${meal.meal_type}</h3>
        <img src="/uploads/${meal.recipe_image}" width="120"/>
        <p>${meal.recipe_title}</p>
      </div>
    `;
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("todayMealPlan")) {
    loadTodayMealPlan();
  }
});

// Delete meal by id
async function deleteMeal(id) {
  try {
    const token = localStorage.getItem('token');
    const res = await fetch(`/api/meal-planner/${id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + token }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Delete failed');
    return true;
  } catch (err) {
    console.error(err);
    alert(err.message || 'Failed to delete');
    return false;
  }
}

// If user navigated from planner intent to view.html, open schedule modal automatically
// Put this at the bottom to run on pages with view.html
window.addEventListener('load', () => {
  try {
    const intent = JSON.parse(localStorage.getItem('mealPlannerIntent') || 'null');
    if (intent && window.location.pathname.includes('view')) {
      localStorage.removeItem('mealPlannerIntent');
      // show an alert instructing user to click the recipe's "Add to Meal Plan" button, and prefill date/meal on modal open
      // To implement prefill: when user clicks Add to Meal Plan on a recipe, script will use scheduleSelectedRecipeId and we set default date/meal
      scheduleDefault = intent; // global helper used by openScheduleModalForRecipe
      alert(`Pick a recipe and click "Add to Meal Plan" to schedule for ${intent.date} (${intent.meal})`);
    }
  } catch(e){}
});

// support prefill - global
let scheduleDefault = null;

function openScheduleModalForRecipe(recipeId) {
  scheduleSelectedRecipeId = recipeId;
  const modal = document.getElementById("scheduleModal");
  if (modal) {
    // default date either from scheduleDefault or today
    document.getElementById("mealDate").value = scheduleDefault?.date || new Date().toISOString().slice(0,10);
    document.getElementById("mealType").value = scheduleDefault?.meal || "Dinner";
    scheduleDefault = null; // reset
    modal.classList.remove("hidden");
  } else {
    const date = prompt("Date (YYYY-MM-DD)", new Date().toISOString().slice(0,10));
    const meal = prompt("Meal (Breakfast, Lunch, Dinner)", "Dinner");
    if (!date || !meal) return;
    saveMealPlan({ date, meal_type: meal, recipe_id: recipeId });
  }
}

// -------------------- Utilities --------------------
